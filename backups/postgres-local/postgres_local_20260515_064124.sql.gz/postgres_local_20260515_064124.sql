--
-- PostgreSQL database dump
--

\restrict HlBKOb9tRJRhjQycZA1aXaVrSuksYaf3eqpGGrzVjrNBrAh1NHk3FVfxn5emZbF

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: test_local; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_local (
    id integer NOT NULL,
    name character varying(100),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.test_local OWNER TO postgres;

--
-- Name: test_local_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_local_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.test_local_id_seq OWNER TO postgres;

--
-- Name: test_local_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_local_id_seq OWNED BY public.test_local.id;


--
-- Name: test_local id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_local ALTER COLUMN id SET DEFAULT nextval('public.test_local_id_seq'::regclass);


--
-- Data for Name: test_local; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_local (id, name, created_at) FROM stdin;
1	Test from local setup	2026-05-15 06:41:04.392278
\.


--
-- Name: test_local_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_local_id_seq', 1, true);


--
-- Name: test_local test_local_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_local
    ADD CONSTRAINT test_local_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict HlBKOb9tRJRhjQycZA1aXaVrSuksYaf3eqpGGrzVjrNBrAh1NHk3FVfxn5emZbF

